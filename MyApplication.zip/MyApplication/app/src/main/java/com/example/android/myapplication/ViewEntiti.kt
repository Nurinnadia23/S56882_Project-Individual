package com.example.android.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ViewEntiti : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_entiti)

        val intent = this.getIntent()
        val entiti = intent.getStringExtra("entiti")

        supportActionBar?.setTitle(entiti)

        //read db
        val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
        val sql = "SELECT importance, due, state, phone FROM list where entiti='$entiti';"
        val cursor = db.rawQuery(sql,null) // guna bila return data

        var importance = ""
        var due = ""
        var state = ""
        var phone = ""

        while (cursor.moveToNext()){
            importance = cursor.getString(0)
            due = cursor.getString(1)
            state = cursor.getString(2)
            phone = cursor.getString(3)
        }
        cursor.close()

        val import = findViewById<EditText>(R.id.inImportance)
        val date = findViewById<EditText>(R.id.inDue)
        val add = findViewById<EditText>(R.id.inAdd)
        val no = findViewById<EditText>(R.id.inPhone)

        import.setText(importance)
        date.setText(due)
        add.setText(state)
        no.setText(phone)

        val btnDel = findViewById<FloatingActionButton>(R.id.btnDelete)
        var delDialog : AlertDialog? = null
        val delBuilder = AlertDialog.Builder(this)
        delBuilder.setTitle("Delete Process")
        delBuilder.setMessage("Are you sure to delete?")

        delBuilder.setNeutralButton("Cancel"){  dialogInterface, which ->
            subToast("Delete Cancelled")
        }
        delBuilder.setPositiveButton("Yes"){  dialogInterface, which ->
            val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
            val sql = "DELETE FROM list where entiti='$entiti';"
            db.execSQL(sql) //guna bila xreturn data
            subToast("Activity $entiti Deleted!")
            val intent = Intent(this, MainActivity::class.java).apply{
            }
            startActivity(intent)
        }
        delDialog = delBuilder.create() // builder create dialog utk delete supaya dapat kita pass pada
        btnDel.setOnClickListener(){
            delDialog.show()

        }

        //-------------------------------------------------------------------

        val btnEdit = findViewById<FloatingActionButton>(R.id.btnEdit)
        var editDialog : AlertDialog? = null
        val editBuilder = AlertDialog.Builder(this)
        editBuilder.setTitle("Update Process")
        editBuilder.setMessage("Are you sure to update the data?")

        editBuilder.setNeutralButton("Cancel"){  dialogInterface, which ->
            subToast("Update Cancelled")
        }
        editBuilder.setPositiveButton("Yes"){  dialogInterface, which ->

            val import = findViewById<EditText>(R.id.inImportance)
            val date = findViewById<EditText>(R.id.inDue)
            val add = findViewById<EditText>(R.id.inAdd)
            val no = findViewById<EditText>(R.id.inPhone)

            val im = import.text.toString()
            val da = date.text.toString()
            val stateAdd = add.text.toString()
            val noPhone = no.text.toString()

            val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
            val sql = "UPDATE list SET importance='$im', due='$da', state='$stateAdd', phone='$noPhone' where entiti='$entiti';"

            db.execSQL(sql) //guna bila xreturn data
            subToast("Activity $entiti updated!")
            val intent = Intent(this, MainActivity::class.java).apply{
            }
            startActivity(intent)
        }
        editDialog = editBuilder.create() // builder create dialog utk delete supaya dapat kita pass pada
        btnEdit.setOnClickListener(){
            editDialog.show()

        }

    }

    private fun subToast(msg: String){
        Toast.makeText( this,msg, Toast.LENGTH_SHORT).show()
    }
}