package com.example.android.myapplication

import android.content.Context
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var entities = ArrayList<String>()

        if(!dbExists(this,"todo")){
            createDB();
        }

        val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
        val sql = "SELECT entiti FROM list"
        val c: Cursor = db.rawQuery(sql,null)
        while (c.moveToNext()){
            val entiti = c.getString(0)
            entities.add(entiti)
        }
        c.close()

        val myAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entities)
        val lv = findViewById<ListView>(R.id.lv)
        lv.setAdapter(myAdapter)
        lv.onItemClickListener = AdapterView.OnItemClickListener { adapter, v, position, arg3 ->
            val value = adapter.getItemAtPosition(position).toString()
            val intent = Intent(this, ViewEntiti::class.java).apply{
                putExtra("entiti", value.toString())
            }
            startActivity(intent)
        }

        val add = findViewById<FloatingActionButton>(R.id.btnAdd)
        add.setOnClickListener({
            val intent = Intent(this, AddEntiti::class.java).apply{

            }
            startActivity(intent)
        })
    }

    private fun dbExists(c: Context, dbName: String):Boolean {
        val dbFile: File = c.getDatabasePath(dbName)
        return dbFile.exists()
    }

    private fun createDB(){
        val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
        subToast("Database todo created!")
        val sqlText = "CREATE TABLE IF NOT EXISTS list " +
                "(entiti VARCHAR(30) PRIMARY KEY, " +
                "importance VARCHAR(30) NOT NULL, " +
                "due VARCHAR(30) NOT NULL, " +
                "state VARCHAR(30) NOT NULL," +
                "phone VARCHAR(30) NOT NULL" +
                ");"
        db.execSQL(sqlText)
        var nextSQL = "INSERT INTO list (entiti,importance,due,state,phone) VALUES ('Ahmad','S55682','Software Engineering', 'Johor','0129869879');"
        db.execSQL(nextSQL)
        nextSQL = "INSERT INTO list (entiti,importance,due,state,phone) VALUES ('Sophea','S55986','Dentistry', 'Sarawak', '0135697896');"
        db.execSQL(nextSQL)
        nextSQL = "INSERT INTO list (entiti,importance,due,state,phone) VALUES ('Harriz','S55017','Medical', 'Terengganu', '01498697865');"
        db.execSQL(nextSQL)
        subToast("3 sample activity added")
    }

    private fun subToast(msg: String){
        Toast.makeText( this,msg, Toast.LENGTH_SHORT).show()
    }
}