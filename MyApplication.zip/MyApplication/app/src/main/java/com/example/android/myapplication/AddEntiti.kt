package com.example.android.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class AddEntiti : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_entiti)

        val btnSave = findViewById<ImageButton>(R.id.btnSave)
        btnSave.setOnClickListener() {
            val entiti = findViewById<EditText>(R.id.inEntiti)
            val importance = findViewById<EditText>(R.id.inImportance)
            val due = findViewById<EditText>(R.id.inDue)
            val state = findViewById<EditText>(R.id.inAdd)
            val phone = findViewById<EditText>(R.id.inPhone)

            val emptyLevel = emptiness(entiti, importance, due)
            if (emptyLevel > 0) {
                // which is empty
                when(emptyLevel){
                    5 -> subToast("Activity must not empty!")
                    6 -> subToast("Importance must not empty!")
                    7 -> subToast("Due Date must not empty!")
                    11 -> subToast("Activity and Importance must not empty!")
                    12 -> subToast("Activity and Due Date must not empty!")
                    13 -> subToast("Importance and Due Date must not empty!")
                    18 -> subToast("Activity, Importance and Due Date must not empty!")
                }
            } else {
                val status = checkKey(entiti.text.toString())
                val ent = entiti.text.toString()
                val import = importance.text.toString()
                val date = due.text.toString()
                val add = state.text.toString()
                val no = phone.text.toString()
                if (!status) {
                    val db = openOrCreateDatabase("todo", MODE_PRIVATE, null)
                    val sql =
                        "INSERT INTO list (entiti, importance, due, state, phone) VALUES ('$ent','$import','$date','$add','$no');"
                    db.execSQL(sql)
                    subToast("New Activity $ent added!")
                    val intent = Intent(this, MainActivity::class.java).apply {
                    }
                    startActivity(intent)
                } else {
                    subToast("Activity already exists inside Database!")
                }
            }
        }
    }

    private fun checkKey(entiti:String):Boolean{
        val db = openOrCreateDatabase("todo", MODE_PRIVATE,null)
        val sql = "SELECT * FROM list WHERE entiti='$entiti'"
        val cursor = db.rawQuery(sql, null)
        var out = false
        if(cursor.count > 0)
            out = true
        return out
    }

    private fun emptiness(entiti: EditText, importance: EditText, due: EditText):Int{
        var empty = 0
        if(entiti.text.isEmpty())
            empty += 5;
        if(importance.text.isEmpty())
            empty += 6;
        if(due.text.isEmpty())
            empty += 7;

        return empty
    }

    private fun subToast(msg: String){
        Toast.makeText( this,msg, Toast.LENGTH_SHORT).show()
    }
}